// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xisolated_accumulator.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XIsolated_accumulator_CfgInitialize(XIsolated_accumulator *InstancePtr, XIsolated_accumulator_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

u32 XIsolated_accumulator_Get_centergroups_BaseAddress(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE);
}

u32 XIsolated_accumulator_Get_centergroups_HighAddress(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_HIGH);
}

u32 XIsolated_accumulator_Get_centergroups_TotalBytes(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE + 1);
}

u32 XIsolated_accumulator_Get_centergroups_BitWidth(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XISOLATED_ACCUMULATOR_CONTROL_WIDTH_CENTERGROUPS;
}

u32 XIsolated_accumulator_Get_centergroups_Depth(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XISOLATED_ACCUMULATOR_CONTROL_DEPTH_CENTERGROUPS;
}

u32 XIsolated_accumulator_Write_centergroups_Words(XIsolated_accumulator *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XIsolated_accumulator_Read_centergroups_Words(XIsolated_accumulator *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE + (offset + i)*4);
    }
    return length;
}

u32 XIsolated_accumulator_Write_centergroups_Bytes(XIsolated_accumulator *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XIsolated_accumulator_Read_centergroups_Bytes(XIsolated_accumulator *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_CENTERGROUPS_BASE + offset + i);
    }
    return length;
}

u32 XIsolated_accumulator_Get_tones_BaseAddress(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE);
}

u32 XIsolated_accumulator_Get_tones_HighAddress(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_HIGH);
}

u32 XIsolated_accumulator_Get_tones_TotalBytes(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE + 1);
}

u32 XIsolated_accumulator_Get_tones_BitWidth(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XISOLATED_ACCUMULATOR_CONTROL_WIDTH_TONES;
}

u32 XIsolated_accumulator_Get_tones_Depth(XIsolated_accumulator *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XISOLATED_ACCUMULATOR_CONTROL_DEPTH_TONES;
}

u32 XIsolated_accumulator_Write_tones_Words(XIsolated_accumulator *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XIsolated_accumulator_Read_tones_Words(XIsolated_accumulator *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE + (offset + i)*4);
    }
    return length;
}

u32 XIsolated_accumulator_Write_tones_Bytes(XIsolated_accumulator *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XIsolated_accumulator_Read_tones_Bytes(XIsolated_accumulator *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_HIGH - XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XISOLATED_ACCUMULATOR_CONTROL_ADDR_TONES_BASE + offset + i);
    }
    return length;
}

